// Auto-generated. Do not edit.


    /**
     */

    declare namespace Mbit_IR {
    }
    
    // Auto-generated. Do not edit. Really.
    