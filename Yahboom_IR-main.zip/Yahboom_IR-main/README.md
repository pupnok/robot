 # Yahboom_IR for micro-bit

Extension for Yahboom IR

Note: IR receiver for Yahboom receiver

## License

MIT

## Supported targets

* for PXT/microbit
(The metadata above is needed for package search.)
